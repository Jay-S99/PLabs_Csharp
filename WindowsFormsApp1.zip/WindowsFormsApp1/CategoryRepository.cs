﻿using Dapper;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using WindowsFormsApp1.Models;


namespace WindowsFormsApp1
{
    public class CategoryRepository
    {
        private readonly string _connectionString;

        public CategoryRepository()
        {
            _connectionString = DataConnection.ConnectionString;
        }

        public List<Category> GetAllCategories()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                return connection.Query<Category>("SELECT * FROM Categories").ToList();
            }
        }

        public void AddCategory(string name, string description)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Execute("INSERT INTO Categories (CategoryName, Description) VALUES (@name, @description)",
                    new { name, description });
            }
        }

        public void UpdateCategory(int id, string name, string description)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Execute("UPDATE Categories SET CategoryName = @name, Description = @description WHERE CategoryID = @id",
                    new { id, name, description });
            }
        }

        public void DeleteCategory(int id)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Execute("DELETE FROM Categories WHERE CategoryID = @id", new { id });
            }
        }
    }
}
