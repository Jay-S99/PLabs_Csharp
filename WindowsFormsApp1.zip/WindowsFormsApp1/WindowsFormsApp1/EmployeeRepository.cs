﻿using Dapper;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using WindowsFormsApp1.Models;

namespace WindowsFormsApp1
{
    public class EmployeeRepository
    {
        private readonly string _connectionString;

        public EmployeeRepository()
        {
            _connectionString = DataConnection.GetConnectionString1();
        }

        public List<Employee> GetAllEmployees()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                return connection.Query<Employee>("SELECT * FROM Employees").ToList();
            }
        }

        public void AddEmployee(string firstName, string lastName, string title)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Execute("INSERT INTO Employees (FirstName, LastName, Title) VALUES (@firstName, @lastName, @title)",
                    new { firstName, lastName, title });
            }
        }

        public void UpdateEmployee(int id, string firstName, string lastName, string title)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Execute("UPDATE Employees SET FirstName = @firstName, LastName = @lastName, Title = @title WHERE EmployeeID = @id",
                    new { id, firstName, lastName, title });
            }
        }

        public void DeleteEmployee(int id)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Execute("DELETE FROM Employees WHERE EmployeeID = @id", new { id });
            }
        }
    }
}
