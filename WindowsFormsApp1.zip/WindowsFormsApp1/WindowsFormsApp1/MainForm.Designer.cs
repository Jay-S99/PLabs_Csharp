﻿using System;
using System.Windows.Forms;
using WindowsFormsApp1;  // Dostęp do repozytoriów  


namespace WindowsFormsApp1
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dataGridViewEmployees;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;

        private System.Windows.Forms.TextBox txtCategoryName;
        private System.Windows.Forms.TextBox txtCategoryDescription;
        private System.Windows.Forms.DataGridView dataGridViewCategories;
        private System.Windows.Forms.Button btnAddCategory;
        private System.Windows.Forms.Button btnUpdateCategory;
        private System.Windows.Forms.Button btnDeleteCategory;
        private void LoadData()
        {
            dataGridViewCategories.DataSource = _categoryRepo.GetAllCategories();
            dataGridViewEmployees.DataSource = _employeeRepo.GetAllEmployees();
        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            string name = txtCategoryName.Text;
            string description = txtCategoryDescription.Text;
            _categoryRepo.AddCategory(name, description);
            LoadData();
        }

        private void btnEditCategory_Click(object sender, EventArgs e)
        {
            if (dataGridViewCategories.SelectedRows.Count > 0)
            {
                int id = (int)dataGridViewCategories.SelectedRows[0].Cells["CategoryID"].Value;
                string name = txtCategoryName.Text;
                string description = txtCategoryDescription.Text;
                _categoryRepo.UpdateCategory(id, name, description);
                LoadData();
            }
        }

        private void btnDeleteCategory_Click(object sender, EventArgs e)
        {
            if (dataGridViewCategories.SelectedRows.Count > 0)
            {
                int id = (int)dataGridViewCategories.SelectedRows[0].Cells["CategoryID"].Value;
                _categoryRepo.DeleteCategory(id);
                LoadData();
            }
        }


        /*
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dataGridViewEmployees;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;

        private System.Windows.Forms.TextBox txtCategoryName;
        private System.Windows.Forms.TextBox txtCategoryDescription;
        private System.Windows.Forms.DataGridView dataGridViewCategories;
        private System.Windows.Forms.Button btnAddCategory;
        private System.Windows.Forms.Button btnUpdateCategory;
        private System.Windows.Forms.Button btnDeleteCategory;



        private void InitializeComponent()
        {
            this.dataGridViewEmployees = new System.Windows.Forms.DataGridView();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.dataGridViewCategories = new System.Windows.Forms.DataGridView();
            this.txtCategoryName = new System.Windows.Forms.TextBox();
            this.txtCategoryDescription = new System.Windows.Forms.TextBox();
            this.btnAddCategory = new System.Windows.Forms.Button();
            this.btnUpdateCategory = new System.Windows.Forms.Button();
            this.btnDeleteCategory = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployees)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCategories)).BeginInit();
            this.SuspendLayout();
            
            this.dataGridViewEmployees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEmployees.Location = new System.Drawing.Point(12, 12);
            this.dataGridViewEmployees.Name = "dataGridViewEmployees";
            this.dataGridViewEmployees.RowHeadersWidth = 62;
            this.dataGridViewEmployees.Size = new System.Drawing.Size(400, 237);
            this.dataGridViewEmployees.TabIndex = 0;
           
            this.txtFirstName.Location = new System.Drawing.Point(450, 21);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(100, 26);
            this.txtFirstName.TabIndex = 1;
            
            this.txtLastName.Location = new System.Drawing.Point(450, 67);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(100, 26);
            this.txtLastName.TabIndex = 2;
             
            this.txtTitle.Location = new System.Drawing.Point(450, 112);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(100, 26);
            this.txtTitle.TabIndex = 3;
            
            this.btnAdd.Location = new System.Drawing.Point(450, 144);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 33);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Dodaj";
            
            this.btnUpdate.Location = new System.Drawing.Point(450, 183);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 31);
            this.btnUpdate.TabIndex = 5;
            this.btnUpdate.Text = "Edytuj";
           
            this.btnDelete.Location = new System.Drawing.Point(450, 220);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 29);
            this.btnDelete.TabIndex = 6;
            this.btnDelete.Text = "Usuń";
            
            this.dataGridViewCategories.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCategories.Location = new System.Drawing.Point(12, 300);
            this.dataGridViewCategories.Name = "dataGridViewCategories";
            this.dataGridViewCategories.RowHeadersWidth = 62;
            this.dataGridViewCategories.Size = new System.Drawing.Size(400, 222);
            this.dataGridViewCategories.TabIndex = 7;
             
            this.txtCategoryName.Location = new System.Drawing.Point(450, 336);
            this.txtCategoryName.Name = "txtCategoryName";
            this.txtCategoryName.Size = new System.Drawing.Size(100, 26);
            this.txtCategoryName.TabIndex = 8;
            
            this.txtCategoryDescription.Location = new System.Drawing.Point(450, 379);
            this.txtCategoryDescription.Name = "txtCategoryDescription";
            this.txtCategoryDescription.Size = new System.Drawing.Size(100, 26);
            this.txtCategoryDescription.TabIndex = 9;
            
            this.btnAddCategory.Location = new System.Drawing.Point(450, 411);
            this.btnAddCategory.Name = "btnAddCategory";
            this.btnAddCategory.Size = new System.Drawing.Size(75, 35);
            this.btnAddCategory.TabIndex = 10;
            this.btnAddCategory.Text = "Dodaj";
            this.btnAddCategory.Click += new System.EventHandler(this.btnAddCategory_Click);
           
            this.btnUpdateCategory.Location = new System.Drawing.Point(450, 452);
            this.btnUpdateCategory.Name = "btnUpdateCategory";
            this.btnUpdateCategory.Size = new System.Drawing.Size(75, 34);
            this.btnUpdateCategory.TabIndex = 11;
            this.btnUpdateCategory.Text = "Edytuj";
            this.btnUpdateCategory.Click += new System.EventHandler(this.btnUpdateCategory_Click);
            
            this.btnDeleteCategory.Location = new System.Drawing.Point(450, 492);
            this.btnDeleteCategory.Name = "btnDeleteCategory";
            this.btnDeleteCategory.Size = new System.Drawing.Size(75, 30);
            this.btnDeleteCategory.TabIndex = 12;
            this.btnDeleteCategory.Text = "Usuń";
            this.btnDeleteCategory.Click += new System.EventHandler(this.btnDeleteCategory_Click);
            
            // MainForm
             
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.ClientSize = new System.Drawing.Size(1272, 616);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.dataGridViewEmployees);
            this.Controls.Add(this.dataGridViewCategories);
            this.Controls.Add(this.txtCategoryName);
            this.Controls.Add(this.txtCategoryDescription);
            this.Controls.Add(this.btnAddCategory);
            this.Controls.Add(this.btnUpdateCategory);
            this.Controls.Add(this.btnDeleteCategory);
            this.Name = "MainForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployees)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCategories)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }*/
    }
}
