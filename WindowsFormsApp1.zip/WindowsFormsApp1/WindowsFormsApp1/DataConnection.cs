﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using System.Configuration;



namespace WindowsFormsApp1.Data
{
    public class DataConnection
    {
        public string GetConnectionString1()
        {
            return "Data Source=DESKTOP-JDSD27G;Initial Catalog=Northwind;Integrated Security=True";
        }

        public string GetConnectionString()
        {
            return GetConnectionString1();
        }
    }

}


/*using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using System.Configuration;



namespace WindowsFormsApp1.Data
{
    public static class DataConnection
    {
        public static string ConnectionString =>
            "Data Source=DESKTOP-JDSD27G;Initial Catalog=Northwind;Integrated Security=True";
    }
}*/
