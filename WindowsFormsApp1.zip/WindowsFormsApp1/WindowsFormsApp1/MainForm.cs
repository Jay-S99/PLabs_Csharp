﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.Models;
using WindowsFormsApp1.Repositories;





namespace WindowsFormsApp1
{
    public partial class MainForm : Form1
    {
        private readonly CategoryRepository _categoryRepo;
        private readonly EmployeeRepository _employeeRepo;

        public MainForm()
        {
            InitializeComponent();
            _categoryRepo = new CategoryRepository();
            _employeeRepo = new EmployeeRepository();
        }
    }


    /*
    public partial class MainForm : Form1
    {
        private readonly IEmployeeRepository _employeeRepository;
        private readonly ICategoryRepository _categoryRepository;

        public MainForm()
        {
            InitializeComponent();
            _employeeRepository = new EmployeeRepository();
            LoadEmployees();
            _categoryRepository = new CategoryRepository();
            LoadCategories();

        }

        private void LoadEmployees()
        {
            dataGridViewEmployees.DataSource = _employeeRepository.GetAll();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var employee = new Employee
            {
                FirstName = txtFirstName.Text,
                LastName = txtLastName.Text,
                Title = txtTitle.Text
            };
            _employeeRepository.Add(employee);
            LoadEmployees();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            var selectedRow = dataGridViewEmployees.SelectedRows[0];
            var employee = new Employee
            {
                EmployeeID = (int)selectedRow.Cells[0].Value,
                FirstName = txtFirstName.Text,
                LastName = txtLastName.Text,
                Title = txtTitle.Text
            };
            _employeeRepository.Update(employee);
            LoadEmployees();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var selectedRow = dataGridViewEmployees.SelectedRows[0];
            int id = (int)selectedRow.Cells[0].Value;
            _employeeRepository.Delete(id);
            LoadEmployees();
        }

        private void LoadCategories()
        {
            dataGridViewCategories.DataSource = _categoryRepository.GetAll();
        }
        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            var category = new Category
            {
                CategoryName = txtCategoryName.Text,
                Description = txtCategoryDescription.Text
            };
            _categoryRepository.Add(category);
            LoadCategories();
        }

        private void btnUpdateCategory_Click(object sender, EventArgs e)
        {
            var selectedRow = dataGridViewCategories.SelectedRows[0];
            var category = new Category
            {
                CategoryID = (int)selectedRow.Cells[0].Value,
                CategoryName = txtCategoryName.Text,
                Description = txtCategoryDescription.Text
            };
            _categoryRepository.Update(category);
            LoadCategories();
        }
        private void btnDeleteCategory_Click(object sender, EventArgs e)
        {
            var selectedRow = dataGridViewCategories.SelectedRows[0];
            int id = (int)selectedRow.Cells[0].Value;
            _categoryRepository.Delete(id);
            LoadCategories();
        }


    }*/
}
