﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WindowsFormsApp1
{
    public class CategoryRepository : IRepository<Categories>
    {
        private readonly NorthwindEntities _context;

        public CategoryRepository()
        {
            _context = new NorthwindEntities();
        }

        public IEnumerable<Categories> GetAll()
        {
            return _context.Category.ToList();
        }

        public Categories GetById(int id)
        {
            return _context.Category.Find(id);
        }

        public void Add(Categories entity)
        {
            _context.Category.Add(entity);
            _context.SaveChanges();
        }

        public void Update(Categories entity)
        {
            var category = _context.Category.Find(entity.CategoryID);
            if (category != null)
            {
                category.CategoryName = entity.CategoryName;
                category.Description = entity.Description;
                _context.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            var category = _context.Category.Find(id);
            if (category != null)
            {
                _context.Category.Remove(category);
                _context.SaveChanges();
            }
        }
    }
}
