﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MainForm : Form1
    {
        private readonly CategoryRepository categoryRepo = new CategoryRepository();
        private readonly EmployeeRepository employeeRepo = new EmployeeRepository();

        public MainForm()
        {
            InitializeComponent();
            LoadCategories();
            LoadEmployees();

            // Eventy przycisków
            btnAddCategory.Click += btnAddCategory_Click;
            btnAddEmployee.Click += btnAddEmployee_Click;
        }

        private void LoadCategories()
        {
           
            var categories = categoryRepo.GetAll().ToList();
            MessageBox.Show("Liczba kategorii: " + categories.Count);
            dgvCategories.AutoGenerateColumns = true;
            dgvCategories.DataSource = categories;
        }

        private void LoadEmployees()
        {
            dgvEmployees.DataSource = employeeRepo.GetAll();
        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            var category = new Categories
            {
                CategoryName = txtCategoryName.Text,
                Description = txtCategoryDescription.Text
            };

            categoryRepo.Add(category);
            LoadCategories();
        }

        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
            var employee = new Employees
            {
                FirstName = txtEmployeeFirstName.Text,
                LastName = txtEmployeeLastName.Text,
                Title = txtEmployeeTitle.Text
            };

            employeeRepo.Add(employee);
            LoadEmployees();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // btnAddCategory
            // 
            this.btnAddCategory.Location = new System.Drawing.Point(80, 250);
            // 
            // btnAddEmployee
            // 
            this.btnAddEmployee.Location = new System.Drawing.Point(80, 514);
            // 
            // txtCategoryName
            // 
            this.txtCategoryName.Location = new System.Drawing.Point(80, 218);
            this.txtCategoryName.TextChanged += new System.EventHandler(this.txtCategoryName_TextChanged);
            // 
            // txtCategoryDescription
            // 
            this.txtCategoryDescription.Location = new System.Drawing.Point(80, 186);
            // 
            // txtEmployeeFirstName
            // 
            this.txtEmployeeFirstName.Location = new System.Drawing.Point(80, 418);
            // 
            // txtEmployeeLastName
            // 
            this.txtEmployeeLastName.Location = new System.Drawing.Point(80, 450);
            // 
            // txtEmployeeTitle
            // 
            this.txtEmployeeTitle.Location = new System.Drawing.Point(80, 482);
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(1084, 611);
            this.Name = "MainForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void txtCategoryName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
