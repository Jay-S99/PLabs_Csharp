﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class EmployeeRepository : IRepository<Employees>
    {
        private readonly NorthwindEntities _context;

        public EmployeeRepository()
        {
            _context = new NorthwindEntities();
        }

        public IEnumerable<Employees> GetAll()
        {
            return _context.Employee.ToList();
        }

        public Employees GetById(int id)
        {
            return _context.Employee.Find(id);
        }

        public void Add(Employees entity)
        {
            _context.Employee.Add(entity);
            _context.SaveChanges();
        }

        public void Update(Employees entity)
        {
            var employee = _context.Employee.Find(entity.EmployeeID);
            if (employee != null)
            {
                employee.FirstName = entity.FirstName;
                employee.LastName = entity.LastName;
                employee.Title = entity.Title;
                _context.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            var employee = _context.Employee.Find(id);
            if (employee != null)
            {
                _context.Employee.Remove(employee);
                _context.SaveChanges();
            }
        }
    }
}
