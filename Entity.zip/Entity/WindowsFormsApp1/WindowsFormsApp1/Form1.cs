﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void SetPlaceholder(object sender, EventArgs e)
        {
            if (sender is TextBox txt && string.IsNullOrWhiteSpace(txt.Text))
            {
                txt.ForeColor = System.Drawing.Color.Gray;
                txt.Text = txt.Name.Replace("txt", "").Replace("Employee", "").Replace("Category", "");
            }
        }

        public void RemovePlaceholder(object sender, EventArgs e)
        {
            if (sender is TextBox txt && txt.ForeColor == System.Drawing.Color.Gray)
            {
                txt.ForeColor = System.Drawing.Color.Black;
                txt.Text = "";
            }
        }
    }
}
