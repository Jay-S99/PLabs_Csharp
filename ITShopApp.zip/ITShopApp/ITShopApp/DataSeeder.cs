﻿using Bogus;
using System;
using System.Linq;
using System.Collections.Generic;


namespace ITShopApp
{


    public static class DataSeeder
    {
        public static void Seed(ShopContext context)
        {
            if (context.Produkty.Any()) return;

            var faker = new Faker("pl");

            // Kategorie
            var kategorie = new List<KategoriaProduktu>
            {
                new KategoriaProduktu { Nazwa = "Laptopy" },
                new KategoriaProduktu { Nazwa = "Monitory" },
                new KategoriaProduktu { Nazwa = "Akcesoria" }
            };
            context.Kategorie.AddRange(kategorie);
            context.SaveChanges();

            // Produkty
            var produkty = new Faker<Produkt>()
                .RuleFor(p => p.Nazwa, f => f.Commerce.ProductName())
                .RuleFor(p => p.IloscNaStanie, f => f.Random.Int(1, 100))
                .RuleFor(p => p.CenaJednostkowa, f => f.Random.Decimal(100, 10000))
                .RuleFor(p => p.Vat, f => 0.23m)
                .RuleFor(p => p.KategoriaProduktu, f => f.PickRandom(kategorie))
                .Generate(30);
            context.Produkty.AddRange(produkty);
            context.SaveChanges();

            // Klienci
            var klienci = new Faker<Klient>()
                .RuleFor(k => k.Nazwa, f => f.Company.CompanyName())
                .RuleFor(k => k.NIP, f => f.Random.Replace("###-###-##-##"))
                .RuleFor(k => k.Adres, f => f.Address.FullAddress())
                .Generate(5);
            context.Klienci.AddRange(klienci);
            context.SaveChanges();

            // Zamówienia
            var zamowienia = new List<Zamowienie>();

            for (int i = 0; i < 10; i++)
            {
                var klient = faker.PickRandom(klienci);
                var zamowienie = new Zamowienie
                {
                    DataRozpoczecia = faker.Date.Past(),
                    DataZakonczenia = null,
                    Status = StatusZamowienia.Rozpoczete,
                    Klient = klient,
                    SzczegolyZamowienia = new List<PozycjaZamowienia>()
                };

                int iloscPozycji = faker.Random.Int(1, 5);
                for (int j = 0; j < iloscPozycji; j++)
                {
                    var produkt = faker.PickRandom(produkty);
                    var ilosc = faker.Random.Int(1, 10);
                    var znizka = faker.Random.Decimal(0, 0.3m);

                    var pozycja = new PozycjaZamowienia
                    {
                        Produkt = produkt,
                        Ilosc = ilosc,
                        CenaJednostkowa = produkt.CenaJednostkowa,
                        Znizka = znizka
                    };

                    zamowienie.SzczegolyZamowienia.Add(pozycja);
                }

                zamowienia.Add(zamowienie);
            }

            context.Zamowienia.AddRange(zamowienia);
            context.SaveChanges();
        }
    }
}