﻿namespace ITShopApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    using System.Data.Entity.ModelConfiguration.Configuration;

    public partial class Init : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.KategoriaProduktu",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Nazwa = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Produkt",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Nazwa = c.String(nullable: false),
                        IloscNaStanie = c.Int(nullable: false),
                        CenaJednostkowa = c.Decimal(nullable: false, precision: 18, scale: 2),
                        Vat = c.Decimal(nullable: false, precision: 18, scale: 2),
                        KategoriaProduktuId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.KategoriaProduktu", t => t.KategoriaProduktuId, cascadeDelete: true)
                .Index(t => t.KategoriaProduktuId);
            
            CreateTable(
                "dbo.Klient",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Nazwa = c.String(),
                        NIP = c.String(),
                        Adres = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.PozycjaZamowienia",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ZamowienieId = c.Int(nullable: false),
                        ProduktId = c.Int(nullable: false),
                        Ilosc = c.Int(nullable: false),
                        CenaJednostkowa = c.Decimal(nullable: false, precision: 18, scale: 2),
                        Znizka = c.Decimal(nullable: false, precision: 18, scale: 2),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Produkt", t => t.ProduktId, cascadeDelete: true)
                .ForeignKey("dbo.Zamowienie", t => t.ZamowienieId, cascadeDelete: true)
                .Index(t => t.ZamowienieId)
                .Index(t => t.ProduktId);
            
            CreateTable(
                "dbo.Zamowienie",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        DataRozpoczecia = c.DateTime(nullable: false),
                        DataZakonczenia = c.DateTime(),
                        Status = c.Int(nullable: false),
                        KlientId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Klient", t => t.KlientId, cascadeDelete: true)
                .Index(t => t.KlientId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.PozycjaZamowienia", "ZamowienieId", "dbo.Zamowienie");
            DropForeignKey("dbo.Zamowienie", "KlientId", "dbo.Klient");
            DropForeignKey("dbo.PozycjaZamowienia", "ProduktId", "dbo.Produkt");
            DropForeignKey("dbo.Produkt", "KategoriaProduktuId", "dbo.KategoriaProduktu");
            DropIndex("dbo.Zamowienie", new[] { "KlientId" });
            DropIndex("dbo.PozycjaZamowienia", new[] { "ProduktId" });
            DropIndex("dbo.PozycjaZamowienia", new[] { "ZamowienieId" });
            DropIndex("dbo.Produkt", new[] { "KategoriaProduktuId" });
            DropTable("dbo.Zamowienie");
            DropTable("dbo.PozycjaZamowienia");
            DropTable("dbo.Klient");
            DropTable("dbo.Produkt");
            DropTable("dbo.KategoriaProduktu");
        }
    }
}
