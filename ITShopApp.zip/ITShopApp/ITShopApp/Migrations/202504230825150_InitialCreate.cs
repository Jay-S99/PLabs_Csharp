﻿namespace ITShopApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            RenameTable(name: "dbo.KategoriaProduktu", newName: "KategoriaProduktu");
            RenameTable(name: "dbo.Produkt", newName: "Produkt");
            RenameTable(name: "dbo.Klient", newName: "Klient");
            RenameTable(name: "dbo.PozycjaZamowienia", newName: "PozycjaZamowienia");
            RenameTable(name: "dbo.Zamowienie", newName: "Zamowienie");
        }
        
        public override void Down()
        {
            RenameTable(name: "dbo.Zamowienie", newName: "Zamowienie");
            RenameTable(name: "dbo.PozycjaZamowienia", newName: "PozycjaZamowienia");
            RenameTable(name: "dbo.Klient", newName: "Klient");
            RenameTable(name: "dbo.Produkt", newName: "Produkt");
            RenameTable(name: "dbo.KategoriaProduktu", newName: "KategoriaProduktu");
        }
    }
}
