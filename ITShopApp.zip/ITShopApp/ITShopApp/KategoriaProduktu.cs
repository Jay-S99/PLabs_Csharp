﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITShopApp
{
    public class KategoriaProduktu
    {
            public int Id { get; set; }
            public string Nazwa { get; set; }

            public virtual ICollection<Produkt> Produkty { get; set; }
        
    }
}
