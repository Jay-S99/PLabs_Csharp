﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITShopApp
{
    public enum StatusZamowienia
    {
        Rozpoczete,
        WRealizacji,
        Zakonczone
    }

    public class Zamowienie
    {
        public int Id { get; set; }
        public DateTime DataRozpoczecia { get; set; }
        public DateTime? DataZakonczenia { get; set; }
        public StatusZamowienia Status { get; set; }

        public virtual ICollection<PozycjaZamowienia> SzczegolyZamowienia { get; set; }

        public decimal KwotaZamowienia => SzczegolyZamowienia?.Sum(p => p.WartoscBrutto) ?? 0;

        public int KlientId { get; set; }
        public virtual Klient Klient { get; set; }
    }

}
