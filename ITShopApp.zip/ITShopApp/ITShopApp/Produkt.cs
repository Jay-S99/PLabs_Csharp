﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITShopApp
{
    public class Produkt
    {
        [Required]
        public int Id { get; set; }
        [Required]
        public string Nazwa { get; set; }
        [Required]
        public int IloscNaStanie { get; set; }
        [Required]
        public decimal CenaJednostkowa { get; set; }
        [Required]
        public decimal Vat { get; set; }
        [Required]
        public int KategoriaProduktuId { get; set; }
        public virtual KategoriaProduktu KategoriaProduktu { get; set; }
    }

}
