﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using ITShopApp;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace ITShopApp
{
  

    public class ShopContext : DbContext
    {
        public DbSet<Produkt> Produkty { get; set; }
        public DbSet<KategoriaProduktu> Kategorie { get; set; }
        public DbSet<Zamowienie> Zamowienia { get; set; }
        public DbSet<PozycjaZamowienia> PozycjeZamowienia { get; set; }
        public DbSet<Klient> Klienci { get; set; }

        public ShopContext() : base("name=ShopConnection") { }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            base.OnModelCreating(modelBuilder);
            
        }
    }

}
