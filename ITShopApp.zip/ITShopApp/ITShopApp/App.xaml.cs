﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using Bogus;
using ITShopApp.Migrations;


namespace ITShopApp
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            using (var context = new ShopContext())
            {
                if (context.Database.Exists())
                {
                    context.Database.Delete();
                }
                else //(!context.Database.Exists())

                    System.Data.Entity.Database.SetInitializer(new MigrateDatabaseToLatestVersion<ShopContext, Configuration>());

                MessageBox.Show("Utworzono nową bazę danych.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                

                
                var istniejaProdukty = context.Produkty.Any();
                if (!istniejaProdukty)
                {
                    var faker = new Faker("pl");

                  
                    var kategorie = new[]
                    {
                        new KategoriaProduktu { Nazwa = "Laptopy" },
                        new KategoriaProduktu { Nazwa = "Smartfony" },
                        new KategoriaProduktu { Nazwa = "Monitory" },
                        new KategoriaProduktu { Nazwa = "Akcesoria" }
                    };
                    context.Kategorie.AddRange(kategorie);
                    context.SaveChanges();

                  
                    var produktFaker = new Faker<Produkt>("pl")
                        .RuleFor(p => p.Id, f => f.IndexVariable)
                        .RuleFor(p => p.Nazwa, f => f.Commerce.ProductName())
                        .RuleFor(p => p.IloscNaStanie, f => f.Random.Int(1, 100))
                        .RuleFor(p => p.CenaJednostkowa, f => f.Random.Decimal(100, 5000))
                        .RuleFor(p => p.Vat, f => 0.23m)
                        .RuleFor(p => p.KategoriaProduktuId, f => f.PickRandom(kategorie).Id);

                    var produkty = produktFaker.Generate(20);
                    context.Produkty.AddRange(produkty);

                    
                    var klientFaker = new Faker<Klient>("pl")
                        .RuleFor(k => k.Nazwa, f => f.Company.CompanyName())
                        .RuleFor(k => k.NIP, f => f.Random.Replace("###-###-##-##"))
                        .RuleFor(k => k.Adres, f => f.Address.FullAddress());

                    var klienci = klientFaker.Generate(5);
                    context.Klienci.AddRange(klienci);

                    context.SaveChanges();
                    
                }
                
            }
        }
    }
}
