﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITShopApp
{
    public class PozycjaZamowienia
    {
        public int Id { get; set; }

        public int ZamowienieId { get; set; }
        public virtual Zamowienie Zamowienie { get; set; }

        public int ProduktId { get; set; }
        public virtual Produkt Produkt { get; set; }

        public int Ilosc { get; set; }
        public decimal CenaJednostkowa { get; set; }
        public decimal Znizka { get; set; }

        public decimal WartoscNetto => Ilosc * CenaJednostkowa;
        public decimal WartoscBrutto => (WartoscNetto * (1 + Produkt.Vat)) * (1 - Znizka);
    }
}
