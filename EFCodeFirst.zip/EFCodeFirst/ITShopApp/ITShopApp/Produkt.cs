﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITShopApp
{
    public class Produkt
    {
        public int Id { get; set; }
        public string Nazwa { get; set; }
        public int IloscNaStanie { get; set; }
        public decimal CenaJednostkowa { get; set; }
        public decimal Vat { get; set; }

        public int KategoriaProduktuId { get; set; }
        public virtual KategoriaProduktu KategoriaProduktu { get; set; }
    }

}
